//
//  War_Card_GameApp.swift
//  War Card Game
//
//  Created by Malyka Sardar  on 2023-06-05.
//

import SwiftUI

@main
struct War_Card_GameApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
